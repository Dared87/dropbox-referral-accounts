[This file has moved to Github](https://github.com/n1k0/casperjs/releases)
