casper.test.begin('test 2', 1, function(test) {
    test.assert(false);
    test.done();
});
